package ExABpackage;

import java.awt.*;

public interface Component {
    void draw(Graphics g);
}