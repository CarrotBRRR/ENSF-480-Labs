#include "GraphicsWorld.cpp"

int main(){
    GraphicsWorld world;
    world.run();

    return 0;
}